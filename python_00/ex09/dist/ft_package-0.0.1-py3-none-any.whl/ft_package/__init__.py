from .count_in_list import count_in_list

"""
    - Python interpreter recognises a folder as the package if it contains
     __init__.py
    - if this file is empty, it will make all functions from other modules
      become available when this package is imported
"""
